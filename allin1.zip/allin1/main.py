from colorama import Style, Back
import os

print('''
                     \033[93m                 .xKo.            ,kKc
                                        'OW0;         .lXNd.
                                         :OOOc       .dOOx.
                               ..        .dl:Oc     .xk:dc        ..
                               ;l         od.:k;    ok.;k;        'l.
                               :0c.      .kd. cx.  :x' ,Ol       .xk.
                               .dK0xddddk0k'  .o:.;o:   cOOxddddkKKc
                                 .;:cccc:'.    'cld:     .,:cccc:,.
                                                ....
                                           \033[94m  BLACKNETID
                          \033[0m           https://t.me/Alone_code404


         ██████╗ ██╗      █████╗  ██████╗██╗  ██╗███╗   ██╗███████╗████████╗██╗██████╗ 
         ██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝████╗  ██║██╔════╝╚══██╔══╝██║██╔══██╗
         ██████╔╝██║     ███████║██║     █████╔╝ ██╔██╗ ██║█████╗     ██║   ██║██║  ██║
         ██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██║╚██╗██║██╔══╝     ██║   ██║██║  ██║
         ██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║ ╚████║███████╗   ██║   ██║██████╔╝
         ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝╚═════╝ 
                                                                                  \033[93mV.0.1
                                      \033[0mWelcome to the \033[91mhell
                                  \033[92mHigh Quality Private Tool   
                                          
                                          
\033[91m[\033[93m1\033[91m]\033[0m Moonton Acount Checker

\033[91m[\033[93m2\033[91m]\033[0m UCwords Combolist

\033[91m[\033[93m3\033[91m]\033[0m Mining Combo List

\033[91m[\033[93m4\033[91m]\033[0m Grab Proxy
                                      
                                      \033[91m[\033[93m99\033[91m]\033[0m Check Updates..
''')
choice = input('\033[92mCHOOSE YOUR NUMBER\033[0m/\033[91mBLACKNETID\033[0m >\033[92m$ \033[0m')
if choice == '1':
    os.system('python Scripts/1/alex.py')
if choice == '2':
    os.system('php Scripts/2/uc.php')
if choice == '3':
    os.system('php Scripts/3/mining.php')
if choice == '4':
    os.system('php Scripts/4/proxy.php')
if choice == '99':
    print('Please Contact \033[93mZLAXTERT \033[0mFor \033[92mUpdates.\n\033[94mhttps://t.me/Alone_code404\033[0m\n')